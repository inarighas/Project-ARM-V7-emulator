#include "run.h"




// Add With Carry //--------------------------------------------------------------------

IMMEDIATE AddWithCarry(unsigned int x ,unsigned int y , unsigned int *carry,unsigned int* Overflow){
  IMMEDIATE result= calloc(1,sizeof(*result));
  if(x->bits != y->bits){
    WARNING_MSG("Erreur Add With Carry");
    return NULL;
  }
  unsigned int unsigned_sum = 0; int signed_sum = 0;
  unsigned_sum = x + y + *carry;
  signed_sum = x + y + *carry;
  result = calloc(1,sizeof(*result));
  result->imm = unsigned_sum ;
  result->bits = 32;
  if(result->imm == unsigned_sum) *carry=0;
  else *carry = 1;
  if(result->imm == signed_sum) *Overflow=0;
  else *Overflow = 1;

  return result;
}


IMMEDIATE AddWithCarry_bis(unsigned int x, unsigned int y , unsigned int *carry, unsigned int* Overflow){
  IMMEDIATE result = calloc(1,sizeof(*result));


  if(*carry=1) {
    result->imm = (x - y);
      result->bits = 32;
      if (x < y) *Overflow = 1;
      else *carry = 1;
  }
  else if(*carry=0) {
    result->imm = (x - y -1 );
    result->bits = x->bits;
      if (x < y) *carry = 1;
      else *Overflow = 1;
  }
  return result;
}


REGISTRE ALUWritePC( unsigned int adress , REGISTRE* table){
  REGISTRE pc;

  pc = trouve_registre("pc",table);
  if (pc == NULL){
    WARNING_MSG("Erreur registre pc introuvable");
    return NULL;
  }
  pc->valeur = adress - (adress % 2);
  return pc;
}



int ADD_IMM(interpreteur inter, DESASM_INST instruction){
	unsigned int result, carry, overflow, imm32;
	REGISTRE Rd = NULL;
	REGISTRE Rn = NULL;
	IMMEDIATE local = NULL;                                   //vu que t'as utilisé des unsigned int :)

	if(strcmp(instruction.inst->identifiant, "ADD_IMM_T1") == 0){
		Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
		Rn = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
		imm32 = instruction.op[2]->unsigned_value->imm;
		instruction.setflag = !(instruction.blockIT);
	}

	else if(strcmp(instruction.inst->identifiant, "ADD_IMM_T2") == 0){
			Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
			Rn = Rd;
			imm32 = instruction.op[1]->unsigned_value->imm;
			instruction.setflag = !(instruction.blockIT);
	}

	else if(strcmp(instruction.inst->identifiant, "ADD_IMM_T3") == 0){
			Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
			Rn = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
			imm32 = instruction.op[2]->unsigned_value->imm;
			unsigned int S = (instruction.code & 0x100000)>>20;		
			instruction.setflag = (S == 1);
			if(Rd->valeur == 13 || (Rd->valeur == 15 && S == 0) || Rn->valeur == 15){
				WARNING_MSG("UNPREDICATBLE");
				return CMD_UNKOWN_RETURN_VALUE;
			}
	}

	else if(strcmp(instruction.inst->identifiant, "ADD_IMM_T4") == 0){
			Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
			Rn = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
			imm32 = instruction.op[2]->unsigned_value->imm;
			instruction.setflag = '0';
			if(Rd->valeur >=13 && Rd->valeur <=15){
				WARNING_MSG("UNPREDICTABLE");
				return CMD_UNKOWN_RETURN_VALUE;
			}
	}

	else {
		WARNING_MSG("probleme d'identifiant dans ADD_IMM");
		return CMD_UNKOWN_RETURN_VALUE;
	}

	//opération :
	carry = 0
	  local  = AddWithCarry(Rn->valeur, imm32,&carry,&overflow);
	if(local == NULL) {
	  ERROR_MSG("Add with carry error");
	  return 1;
	}
	Rd->valeur = local->imm;

	//Mise à jour des registres d'état en option :
	if(instruction.setflag){
		inter->fulltable[1][0]->valeur = result;				//APSR.N
		inter->fulltable[1][1]->valeur = IsZeroBit(result);		//APSR.Z
		inter->fulltable[1][2]->valeur = carry;					//APSR.C
		inter->fulltable[1][3]->valeur = overflow;				//ASPR.V
	}
	free(local);
	return CMD_OK_RETURN_VALUE;
}

/*
int ADD_REG(interpreteur inter, DESASM_INST instruction){
	unsigned int result, carry, overflow;
	int* shift_t = NULL;
	int* shift_n = NULL;
	REGISTRE Rd = NULL;
	REGISTRE Rn = NULL;
	REGISTRE Rm = NULL;

	if(strcmp(instruction.inst->identifiant, "ADD_REG_T1") == 0){
		Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
		Rn = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
		Rm = trouve_registre(instruction.op[2]->register_name, inter->fulltable[0]);
		instruction.setflag = !(instruction.blockIT);
	}

	else if(strcmp(instruction.inst->identifiant, "ADD_REG_T2") == 0){
			Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
			Rn = Rd;
			Rm = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
			if(){
				WARNING_MSG("UNPREDICATBLE");
				return CMD_UNKOWN_RETURN_VALUE;
			}
			instruction.setflag = 0;
	}

	else if(strcmp(instruction.inst->identifiant, "ADD_REG_T3") == 0){
			Rd = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
			Rn = trouve_registre(instruction.op[1]->register_name, inter->fulltable[0]);
			Rm = trouve_registre(instruction.op[2]->register_name, inter->fulltable[0]);
			unsigned int S = (instruction.code & 0x100000)>>20;		
			instruction.setflag = (S == 1);
			decodeIMMshift(???????????????? shift_t, shift_n)
			if(Rd->valeur == 13 || (Rd->valeur == 15 && S == 0) || Rn->valeur == 15){
				WARNING_MSG("UNPREDICATBLE");
				return CMD_UNKOWN_RETURN_VALUE;
			}
	}

	else {
		WARNING_MSG("probleme d'identifiant dans ADD_REG");
		return CMD_UNKOWN_RETURN_VALUE;
	}

	(result, carry, overflow) = addWithCarry(Rn->valeur, imm32, '1');

	if(Rd->valeur==15)ALUWritePC(result);

	else{
		Rd->valeur = result;
		if(instruction.setflag){
			inter->fulltable[1][0]->valeur = result;				//APSR.N
			inter->fulltable[1][1]->valeur = IsZeroBit(result);		//APSR.Z
			inter->fulltable[1][2]->valeur = carry;					//APSR.C
			inter->fulltable[1][3]->valeur = overflow;				//ASPR.V
		}
	}
	return CMD_OK_RETURN_VALUE;
}
*/

int CMP_IMM(interpreteur inter, DESASM_INST instruction){
        IMMEDIATE result=NULL;
	unsigned int carry;
	unsigned int overflow;
	REGISTRE Rn = trouve_registre(instruction.op[0]->register_name, inter->fulltable[0]);
	unsigned int imm32 = instruction.op[1]->unsigned_value->imm;

	if(strcmp(instruction.inst->identifiant, "CMP_IMM_T2") == 0 && Rn->valeur == 15){
		WARNING_MSG("UNPREDICATBLE");
		return CMD_UNKOWN_RETURN_VALUE;
	}
	carry = 1;
	result = AddWithCarry_bis(Rn->valeur,imm32,&carry,&overflow);
	inter->fulltable[1][0]->valeur = result->imm;				//APSR.N
	inter->fulltable[1][1]->valeur = IsZeroBit(result);	             	//APSR.Z
	inter->fulltable[1][2]->valeur = carry;					//APSR.C
	inter->fulltable[1][3]->valeur = overflow;				//ASPR.V
	free(result);
	return CMD_OK_RETURN_VALUE;
}

/*

int MOV_IMM(interpreteur inter, DESASM_INST instruction, REGISTRE Rn, unsigned int imm3, unsigned int imm2){
	unsigned int result;
	unsigned int carry;
	unsigned int overflow;
	unsigned int d = Rd->valeur;
	unsigned int m = Rm->valeur;
	unsigned int n = Rn->valeur;
	int* shift_t, shift_n;
	IMMEDIATE type;

	if(strcmp(instruction.inst->identifiant, "CMP_IMM_T1") == 0){
		instruction.setflag = !(instruction.blockIT);
		carry = inter->fulltable[1][2];
	}

	if(strcmp(instruction.inst->identifiant, "CMP_IMM_T2") == 0){
		if(d>=13 && d<=15){
			WARNING_MSG("UNPREDICTABLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}
		instruction.setflag = (S=='1');
		carry = inter->fulltable[1][2];
	}

	if(strcmp(instruction.inst->identifiant, "CMP_IMM_T3") == 0){
		if(d>=13 && d<=15){
			WARNING_MSG("UNPREDICTABLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}
		instruction.setflag = '0';
	}

	result=imm32;
	Rd->valeur = result;
	if(instruction->setflag){
		inter->fulltable[1][0]->valeur = result;				//APSR.N
		inter->fulltable[1][1]->valeur = IsZeroBit(result);		//APSR.Z
		inter->fulltable[1][2]->valeur = carry;					//APSR.C
		//ASPR.V unchanged
	}
	return CMD_OK_RETURN_VALUE;
}


int MOV_REG(interpreteur inter, DESASM_INST instruction, REGISTRE Rd, REGISTRE Rm){
	unsigned int result;
	unsigned int carry;
	unsigned int overflow;
	unsigned int d = Rd->valeur;
	unsigned int m = Rm->valeur;

	if(strcmp(instruction.inst->identifiant, "CMP_REG_T1") == 0){
		if(d==15 && instruction.blockIT){//&& lastInITblock){
			WARNING_MSG("UNPREDICTABLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}
		instruction.setflag = '0';
	}

	if(strcmp(instruction.inst->identifiant, "CMP_REG_T2") == 0){
		if(instruction.blockIT){
			WARNING_MSG("UNPREDICTABLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}
		instruction.setflag = '1';
	}

	if(strcmp(instruction.inst->identifiant, "CMP_REG_T3") == 0){
		instruction.setflag = (S=='1');
		if(setflag && (d>=13 || d<=15) && (m>=13 || m<=15)){
			WARNING_MSG("UNPREDICTABLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}
		if(!setflag && (d==15 || m==15 || d==13 && m==13)){
			WARNING_MSG("UNPREDICATBLE");
			return CMD_UNKOWN_RETURN_VALUE;
		}

		result = Rm->valeur;
		if(d==15){
			ALUWritePC(result);
			return CMD_OK_RETURN_VALUE;
		}
		else {
			Rd->valeur = result;
			if(instruction.setflag){
				inter->fulltable[1][0]->valeur = result;				//APSR.N
				inter->fulltable[1][1]->valeur = IsZeroBit(result);		//APSR.Z
				//APSR.C unchanged
				//ASPR.V unchanged
			}
			return CMD_OK_RETURN_VALUE;
		}
		
	}*/
}

/*int find_inst(interpreteur inter, DESASM_INST instruction){
	switch(instruction.id){
		case 0:
			return ADD_IMM_T1(inter, instruction);
			break;

		case 1:
			return ADD_IMM_T2(inter, instruction);
			break;
		case 2:
			return ADD_IMM_T3(inter, instruction);
			break;
		case 3:
			return ADD_IMM_T4(inter, instruction);
			break;
		case 4:
			return ADD_REG_T1(inter, instruction);
			break;

		case 5:
			return ADD_REG_T2(inter, instruction);
			break;

		case 6:
			return ADD_REG_T3(inter, instruction);
			break;

		case 7:
			return B_T1(inter, instruction);
			break;

		case 8:
			return B_T2(inter, instruction);
			break;
	}
}*/



/*int _runcmd(interpreteur inter, unsigned int adresse){
	int state = RUN;
    while(1){
        switch(state){

            case PAUSE:
                state = RUN;
                break;

            case RUN:
            	//desasm();
            	//DESASM_INST instruction = 
                break;

            default:
            printf("NEVER SHOULD BE HERE\n");
            return 1;
            break;
        }
    }
}
*/
