/**
 *
 * @file emulARM.c
 * @author François Cayre, Nicolas Castagné, François Portet
 * @brief Main pour le début du projet émulateur.
 *
 */

/////////////////////////////////////////////////////////////////////////////////////

#include "projetemularm.h"

/**
 * @param in Input line (possibly very badly written).
 * @param out Line in a suitable form for further analysis.
 * @return nothing
 * @brief This function will prepare a line for further analysis.
 *
 * This function will prepare a line for further analysis and check for low-level syntax errors.
 * colon, brackets, commas are surrounded with blank; tabs are replaced with blanks.
 * negs '-' are attached to the following token (e.g., "toto -   56" -> "toto -56")  .
 */
void string_standardise( char* in, char* out ) {
    unsigned int i=0, j;

    for ( j= 0; i< strlen(in); i++ ) {

        /* insert blanks around special characters*/
        if (in[i]==':' || in[i]=='+' || in[i]=='~') {
            out[j++]=' ';
            out[j++]=in[i];
            out[j++]=' ';

        }

        /* remove blanks after negation*/
        else if (in[i]=='-') {
            out[j++]=' ';
            out[j++]=in[i];
            while (isblank((int) in[i+1])) i++;
        }

        /* insert one blank before comments */
        else if (in[i]=='#') {
            out[j++]=' ';
            out[j++]=in[i];
        }
        /* translate tabs into white spaces*/
        else if (isblank((int) in[i])) out[j++]=' ';
        else out[j++]=in[i];
    }
}


/**
 *
 * @brief extrait la prochaine ligne du flux fp.
 * Si fp ==stdin, utilise la librairie readline pour gestion d'historique de commande.
 *
 * @return 0 si succes.
 * @return un nombre non nul si aucune ligne lue
 */
int  acquire_line(FILE *fp, interpreteur inter) {
    char* chunk =NULL;

    memset(inter->input, '\0', MAX_STR );
    inter->first_token =0;
    if (inter->mode==SCRIPT) {
        // mode fichier
        // acquisition d'une ligne dans le fichier
        chunk =calloc(MAX_STR, sizeof(*chunk));
        char * ret = fgets(chunk, MAX_STR, fp );
        if(ret == NULL) {
            free(chunk);
            return 1;
        }
        // si windows remplace le \r du '\r\n' (fin de ligne windows) par \0
        if(strlen(ret) >1 && ret[strlen(ret) -2] == '\r') {
            ret[strlen(ret)-2] = '\0';
        }
        // si unix remplace le \n par \0
        else if(strlen(ret) >0 && ret[strlen(ret) -1] == '\n') {
            ret[strlen(ret)-1] = '\0';
        }

    }
    else {
        /* mode shell interactif */
        /* on utilise la librarie libreadline pour disposer d'un historique */
        chunk = readline( PROMPT_STRING );
        if (chunk == NULL || strlen(chunk) == 0) {
            /* commande vide... */
            if (chunk != NULL) free(chunk);
            return 1;
        }
        /* ajout de la commande a l'historique, librairie readline */
        add_history( chunk );

    }
    // standardisation de la ligne d'entrée (on met des espaces là ou il faut)
    string_standardise(chunk, inter->input);

    free( chunk ); // liberation de la mémoire allouée par la fonction readline() ou par calloc()

    DEBUG_MSG("Ligne acquise '%s' ", inter->input); /* macro DEBUG_MSG : uniquement si compil en mode DEBUG_MSG */
    return 0;
}


/****************/
void usage_ERROR_MSG( char *command ) {
    fprintf( stderr, "Usage: %s [file.emul]\n   If no file is given, executes in Shell mode.", command );
}


/**
 * Programme principal
 */
int main ( int argc, char *argv[] ) {
    /* exemples d'utilisation des macros du fichier notify.h */
    INFO_MSG("Un message INFO_MSG : Debut du programme %s", argv[0]); /* macro INFO_MSG */
    interpreteur inter=init_inter();

    unsigned int i = 0;
    for(i=0; i<13; i++)inter->fulltable[0][i]->valeur = 3;

    afficher_table_registre(inter->fulltable[0]);

    DESASM_INST instruction;
    instruction.inst = calloc(1,sizeof(TYPE_INST));
    strcpy(instruction.inst->identifiant,"ADD_IMM_T1");
    strcpy(instruction.inst->mnemo,"ADD");

    instruction.op[0]=calloc(1,sizeof(OPERANDE));
    instruction.op[0]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction.op[0]->register_name, "r1");

    instruction.op[1]=calloc(1,sizeof(OPERANDE));
    instruction.op[1]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction.op[1]->register_name, "r6");

    instruction.op[2]=calloc(1,sizeof(OPERANDE));
    instruction.op[2]->unsigned_value = calloc(1,sizeof(IMMEDIATE));
    instruction.op[2]->unsigned_value->imm = 0x4;
    instruction.op[2]->unsigned_value->bits = '3';

    instruction.code = 0x1D31;      //correspond à ADD_IMM_T1
                                    // avec Rd = r1, Rn = 6, imm32 = 4

    INFO_MSG("1er test : Lancement de ADD_IMM_T1");
    INFO_MSG("code : %x",instruction.code);

    INFO_MSG("\nRd : %s\nRn : %s\nimm32 = %u",trouve_registre(instruction.op[0]->register_name, inter->fulltable[0])->nom,
                                            trouve_registre(instruction.op[1]->register_name, inter->fulltable[0])->nom,
                                            instruction.op[2]->unsigned_value->imm);

    ADD_IMM(inter, instruction);

    afficher_table_registre(inter->fulltable[0]);

    DESASM_INST instruction2;

    instruction2.inst = calloc(1,sizeof(TYPE_INST));
    strcpy(instruction2.inst->identifiant,"ADD_IMM_T1");
    strcpy(instruction2.inst->mnemo,"ADD");

    instruction2.op[0]=calloc(1,sizeof(OPERANDE));
    instruction2.op[0]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction2.op[0]->register_name, "r1");

    instruction2.op[1]=calloc(1,sizeof(OPERANDE));
    instruction2.op[1]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction2.op[1]->register_name, "r7");


    instruction2.op[2]=calloc(1,sizeof(OPERANDE));
    instruction2.op[2]->unsigned_value = calloc(1,sizeof(IMMEDIATE));
    instruction2.op[2]->unsigned_value->imm = 0x6;
    instruction2.op[2]->unsigned_value->bits = '3';

    instruction2.code = 0x1DB9;      //correspond à ADD_IMM_T1
                                    // avec Rd = r1, Rn = r7, imm32 = 6

    INFO_MSG("2eme test : Lancement de ADD_IMM_T1");
    INFO_MSG("code : %x",instruction2.code);

    INFO_MSG("\nRd : %s\nRn : %s\nimm32 = %u",trouve_registre(instruction2.op[0]->register_name, inter->fulltable[0])->nom,
                                            trouve_registre(instruction2.op[1]->register_name, inter->fulltable[0])->nom,
                                            instruction2.op[2]->unsigned_value->imm);
    ADD_IMM(inter, instruction2);
    afficher_table_registre(inter->fulltable[0]);

    DESASM_INST instruction3;

    instruction3.inst = calloc(1,sizeof(TYPE_INST));
    strcpy(instruction3.inst->identifiant,"ADD_IMM_T1");
    strcpy(instruction3.inst->mnemo,"ADD");

    instruction3.op[0]=calloc(1,sizeof(OPERANDE));
    instruction3.op[0]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction3.op[0]->register_name, "r0");

    instruction3.op[1]=calloc(1,sizeof(OPERANDE));
    instruction3.op[1]->register_name=calloc(1,3*sizeof(char));
    strcpy(instruction3.op[1]->register_name, "r7");


    instruction3.op[2]=calloc(1,sizeof(OPERANDE));
    instruction3.op[2]->unsigned_value = calloc(1,sizeof(IMMEDIATE));
    instruction3.op[2]->unsigned_value->imm = 0x6;
    instruction3.op[2]->unsigned_value->bits = '3';

    instruction3.code = 0x1DB8;      //correspond à ADD_IMM_T1
                                    // avec Rd = r0, Rn = r7, imm32 = 6

    INFO_MSG("3eme test : Lancement de ADD_IMM_T1");
    INFO_MSG("code : %x",instruction3.code);

    INFO_MSG("\nRd : %s\nRn : %s\nimm32 = %u",trouve_registre(instruction3.op[0]->register_name, inter->fulltable[0])->nom,
                                            trouve_registre(instruction3.op[1]->register_name, inter->fulltable[0])->nom,
                                            instruction3.op[2]->unsigned_value->imm);
    ADD_IMM(inter, instruction3);
    afficher_table_registre(inter->fulltable[0]);
}







