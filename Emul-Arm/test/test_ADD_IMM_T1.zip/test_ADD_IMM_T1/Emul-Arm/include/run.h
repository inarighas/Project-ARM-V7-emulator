#ifndef _run_
#define _run_


#include "projetemularm.h"

#define NOT_STARTED 0
#define RUN 1
#define PAUSE 2


int ADD_IMM(interpreteur inter, DESASM_INST instruction);
int CMP_IMM(interpreteur inter, DESASM_INST instruction);
IMMEDIATE AddWithCarry(unsigned int x ,unsigned int y , unsigned int *carry,unsigned int* Overflow);
IMMEDIATE AddWithCarry_bis(unsigned int x, unsigned int y , unsigned int *carry, unsigned int* Overflow);
REGISTRE ALUWritePC( unsigned int adress , REGISTRE* table);
unsigned int IsZeroBit(unsigned int chaine_bit);



#endif